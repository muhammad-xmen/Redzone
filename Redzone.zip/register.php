<?php
include('./inc/nav.php');
include('./inc/register.inc.php');
?>
<div class="Register">
    <div class="container   p-4 mt-5 col-lg-6 col-sm shadow-sm ">
        <div class="row p-4 ">
            <?php if (isset($_POST['register_user'])) { ?>
                <p class="text-danger text-center fs-5"><?php echo $error['err']; ?></p>
            <?php } ?>
        </div>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
            <div class="mb-3 d-flex">
                <input type="text" class="form-control w-50 m-1" name="lastName" placeholder="ناوی بابت" <?php if (isset($_POST['register_user'])) { ?> value="<?php echo $lastName; ?>" <?php } ?>>
                <input type="text" class="form-control w-50 m-1" name="firstName" placeholder="ناوی خۆت" <?php if (isset($_POST['register_user'])) { ?> value="<?php echo $firstname; ?>" <?php } ?>>
            </div>
            <div class="mb-3> d-flex">
                <input type="text" class="form-control w-50 m-1  " name="number_phone" placeholder="ژمارەی مۆبایل" <?php if (isset($_POST['register_user'])) { ?> value="<?php echo $phone; ?>" <?php } ?>>
                <select name="gender" id="" class="form-control w-50 m-1 text-center" <?php if (isset($_POST['register_user'])) { ?> value="<?php echo $gender  ?> <?php } ?>">
                    <option value="null">رەگەز دیاری بکە</option>
                    <option value="male">نێر</option>
                    <option value="female">مێ</option>
                </select>
            </div>
            <div class="mb-3">
                <input type="file" class="form-control m-1" name="image" <?php if (isset($_POST['register_user'])) { ?> value="<?php echo $photo  ?>"> <?php } ?>
            </div>
            <div class="mb-3">
                <input type="text" class="form-control  m-1" name="city" placeholder="شوێنی نیشتە جێبوون" <?php if (isset($_POST['register_user'])) { ?> value="<?php echo $city  ?>"> <?php } ?>
            </div>
            <div class="mb-3 ">
                <input type="email" class="form-control  m-1" name="email" placeholder="ئیمێڵ" <?php if (isset($_POST['register_user'])) { ?> value="<?php echo $email  ?>" <?php } ?>>
            </div>
            <div class="mb-3 ">
                <input type="password" class="form-control  m-1" name="password" placeholder="وشەی نهێنی">
            </div>
            <div class="mb-3 ">
                <input type="password" class="form-control  m-1" name="password_con" placeholder="دووبارە کردنەوەی وشەی نهێنی">
            </div>
            <br>
            <button type="submit" class="btn_register" name="register_user">خۆتۆمار کردن</button>
        </form>
    </div>
    <div class="row text-center mt-5">
        <a href="login.php">چوونەژورەوە</a>
    </div>
</div>
<?php include('./inc/footer.php'); ?>