<?php require('./inc/nav.php'); ?>
<div class="row justify-content-center  " style="margin-top:50px;">
    <?php
    $query = mysqli_query($db, "SELECT * FROM `item` WHERE `type_item` = 'computer' ORDER BY `id` DESC");
    if ($query) {
        while ($row = mysqli_fetch_array($query)) {
            $id = $row['id'];
            $name = $row['name'];
            $details = $row['details'];
            $price = $row['price'];
            $photo = $row['photo'];
    ?>
            <div class="card home m-2" style="width: 16rem; height:23rem;position:relative;">
                <img src="./Admin/upload/<?php echo $photo; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title text-center p-2 fs-4"><?php echo $name; ?></h5>
                    <!-- <p class="card-text text-justify "><?php echo $details; ?></p> -->
                    <p class="card-text text-left"><?php echo $price; ?>$</p>
                    <div class="bottom">
                        <a href="view.php?id=<?php echo $id; ?>"><i class="fas fa-eye me-2"></i>بینینی بەرهەم</a>
                        <a href="buy.php?buy=<?php echo $id; ?>"><i class='bx bxs-shopping-bag me-2'></i>کرین</a>
                    </div>
                </div>
            </div>
    <?php
        }
    } else {
        echo '<p class="text-danger fs-3 text-center mt-5 p-3">هیچ داتایەک نیە</p>';
    }
    ?>
</div>
<?php require('./inc/footer.php'); ?>