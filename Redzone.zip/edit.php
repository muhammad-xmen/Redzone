<?php require('./inc/nav.php'); ?>
<?php
redirect('index.php');
?>
<?php
if (isset($_SESSION['User_Id'])) {
    $user_id = $_SESSION['User_Id'];
    $sql = "SELECT * FROM `user` WHERE `user_id` = '$user_id'";
    $query = mysqli_query($db, $sql);
    if ($query) {
        // echo 'data haya';
        $row = mysqli_fetch_array($query);
        $id = $row['id'];
        $name = $row['name'];
        $phone = $row['phone'];
        $email = $row['email'];
        $city = $row['city'];
    } else {
        echo 'data nya';
    }
}
?>
<?php include('./user/update.php'); ?>
<div class="container p-5 mt-5">
    <div class="row justify-content-center">
        <form class=" col-lg-6 col-sm-10" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="mb-3">
                <input type="text" name="Newname" class="form-control  p-3 fs-5" value="<?php echo $name; ?>">
                <input type="hidden" name="id" class="form-control" value="<?php echo $id; ?>">
            </div>
            <div class="mb-3">
                <input type="text" name="Newphone" class="form-control p-3 fs-5" value="<?php echo $phone; ?>">
            </div>
            <div class="mb-3">
                <input type="email" name="Newemail" class="form-control p-3 fs-5" value="<?php echo $email; ?>">
            </div>
            <div class="mb-3">
                <input type="text" name="Newcity" class="form-control p-3 fs-5" value="<?php echo $city; ?>">
            </div>
            <div class="row  mt-5">
                <button type="submit" class="btn btn-primary w-50 m-auto " name="update">Update</button>
            </div>
        </form>
    </div>
</div>
<?php require('./inc/footer.php'); ?>