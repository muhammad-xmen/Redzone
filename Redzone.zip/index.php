<?php require('./inc/nav.php'); ?>

<div class="row">
    <?php
    if (isset($_SESSION['order'])) {
        function_alert($_SESSION['order']);
        unset($_SESSION['order']);
    }
    ?>
</div>

<div class="heading ">
    <h3> بەخێربێت بۆ <span> ناوچەی </span>سور</h3>
    <p> لێرە دەتوانی کالاکان بەنرخێکی گونجاو دەستت بکەوێ</p>
    <!-- <?php //if (!isset($_SESSION['UserLogin'])) { 
            ?>
            <p class="user">ئەگەر ئەکاونتت نیە خۆت تۆماربکە بۆ کرینی بابەت</p>
        <?php //} 
        ?> -->
</div>
<div class="container text-center fs-3 mt-3 text-dark ">
    <p>کۆمپیوتەر</p>
</div>
<div class="row p-3 mt-2 justify-content-center home-page">
    <div class="row ">
        <?php
        if (isset($_SESSION['logged-in'])) {
            echo $_SESSION['logged-in'];
            unset($_SESSION['logged-in']);
        }
        ?>
        <p class="text-center text-dnager">
            <?php
            if (!isset($_SESSION['UserLogin'])) {
                echo ' تکایە گەر ئەکاونتت نیە پەنجە لە <a href="register.php"> خۆتۆمارکردن</a> بدە';
                unset($_SESSION['user-login']);
            }
            ?>
        </p>
    </div>
    <?php
    $query = mysqli_query($db, "SELECT * FROM `item` WHERE `type_item`= 'computer' LIMIT 10 ");
    if ($query) {
        while ($row = mysqli_fetch_assoc($query)) {
            $id = $row['id'];
            $name = $row['name'];
            $details = $row['details'];
            $price = $row['price'];
            $photo = $row['photo'];
    ?>
            <div class="card home m-1" style="width: 16rem; height:23rem;position:relative;">
                <img src="./Admin/upload/<?php echo $photo; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title text-center p-2 fs-4"><?php echo $name; ?></h5>
                    <!-- <p class="card-text text-justify "><?php echo $details; ?></p> -->
                    <p class="card-text text-left"><?php echo $price; ?>$</p>
                    <div class="bottom">
                        <a href="view.php?id=<?php echo $id; ?>"><i class="fas fa-eye me-2"></i>بینینی بەرهەم</a>
                        <a href="buy.php?buy=<?php echo $id; ?>"><i class='bx bxs-shopping-bag me-2'></i>کرین</a>
                    </div>
                </div>
            </div>
    <?php
        }
    } else {
        echo '<p class="text-danger text-center fs-3">هیچ داتایەک نیە</p>';
    }
    ?>
</div>
<div class="row text-center fs-5 mt-5 text-decoration-underline"><a href="./computer.php">بەرهەمی زیاتر</a></div>
<div class="col-lg-11 col-sm-10 m-auto">
    <hr>
</div>
<div class="container text-center fs-3 mt-5 text-dark">
    <p>مۆبایل</p>
</div>
<div class="row p-3 mt-5 justify-content-center home-page">
    <?php
    $query = mysqli_query($db, "SELECT * FROM `item` WHERE `type_item`= 'mobile' LIMIT 10 ");
    if ($query) {
        while ($row = mysqli_fetch_assoc($query)) {
            $id = $row['id'];
            $name = $row['name'];
            $details = $row['details'];
            $price = $row['price'];
            $photo = $row['photo'];
    ?>
            <div class="card home m-1" style="width: 16rem; height:23rem;position:relative;">
                <img src="./Admin/upload/<?php echo $photo; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title text-center p-2 fs-4"><?php echo $name; ?></h5>
                    <!-- <p class="card-text text-justify "><?php echo $details; ?></p> -->
                    <p class="card-text text-left"><?php echo $price; ?>$</p>
                    <div class="bottom">
                        <a href="view.php?id=<?php echo $id; ?>"><i class="fas fa-eye me-2"></i>بینینی بەرهەم</a>
                        <a href="buy.php?buy=<?php echo $id; ?>"><i class='bx bxs-shopping-bag me-2'></i>کرین</a>
                    </div>
                </div>
            </div>
    <?php
        }
    } else {
        echo '<p class="text-danger text-center fs-3">هیچ داتایەک نیە</p>';
    }
    ?>
    <div class="row text-center fs-5 mt-2 text-decoration-underline"><a href="./mobile.php">بەرهەمی زیاتر</a></div>
    <div class="col-lg-11 col-sm-10 m-auto">
        <hr>
    </div>
</div>
<div class="container text-center fs-3 mt-5 text-dark">
    <p>خزمەت گوزاریەکان</p>
</div>
<div class="row justify-content-center p-2 m-2 gap-4">
    <?php
    $i = 1;
    while ($i < 4) {
    ?>
        <div class="card m-2 shadow-sm p-2" style="width: 20rem; height:auro;">
            <img src="./assets/img/<?php if ($i == 1) {
                                        echo 'fast-delivery.png';
                                    } elseif ($i == 2) {
                                        echo 'service.png';
                                    } else {
                                        echo 'discounts.png';
                                    } ?>" class="card-img-top" style="width:130px; height:auto;object-fit:cover;
                                    margin: 20px auto;">
            <div class="card-body">
                <h5 class="card-title text-center fs-4 mb-3"><?php
                                                                if ($i == 1) {
                                                                    echo 'گەیاندن';
                                                                } elseif ($i == 2) {
                                                                    echo 'دەستکەوتنی کاڵاکان';
                                                                } else {
                                                                    echo 'داشکاندن';
                                                                }
                                                                ?></h5>
                <p class="card-text text-center">
                    <?php
                    if ($i == 1) {
                        echo ' گەیاندنی کاڵاکان بە زوترین کات و بە خۆڕایی';
                    } elseif ($i == 2) {
                        echo 'بە شێوازیکی ئاسان کالاکانت دەست دەکەوێت';
                    } else {
                        echo 'داشکاندنی مانگانە و ساڵانە لە کاڵاکان ';
                    }
                    ?>
                </p>
            </div>
        </div>
    <?php
        $i++;
    }
    ?>
</div>

<?php require('./inc/footer.php'); ?>