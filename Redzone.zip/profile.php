<?php include('./inc/nav.php') ?>
<?php
redirect('index.php');
?>
<?php
if (isset($_GET['user_id'])) {
    $id = clear($_GET['user_id']);
    $query_user = mysqli_query($db, "SELECT * FROM `user` WHERE `user_id` = '$id'");
    if ($query_user) {
        if (mysqli_num_rows($query_user) == 0) {
            // echo 'nya';
            header('Location:index.php');
        } else {
            //echo 'haya';
            while ($row = mysqli_fetch_array($query_user)) {
                $fullname = $row['name'];
                $phone = $row['phone'];
                $email = $row['email'];
                $city = $row['city'];
                $date = $row['date'];
                $gender = $row['gender'];
                $photo = $row['photo'];
            }
        }
    }
}
?>
<div class="container mt-4 mb-4 p-5 d-flex justify-content-center">
    <div class="card p-3  shadow-sm ">
        <div class=" image d-flex flex-column justify-content-center align-items-center">
                <img src="./user/upload/<?php echo  $photo; ?>" style="width:300px;height:auto;object-fit:cover;" >
            <span class="name mt-3"><?php echo $fullname; ?> : ناو </span>
            <span class="phone"><?php echo $phone ?> : ژمارەی مۆبایل </span>
            <span class="phone"><?php echo $gender ?> : رەگەز </span>
            <span class="phone text-lowercase"><?php echo $email ?> : ئیمێڵ </span>
            <div class=" d-flex mt-2 ">
                <button class="btn1 m-1"><a href="./edit.php"> Edit Profile </a></button>
                <button class="btn1 btn-primary  m-1 w-50"><a href="./change.php?id=<?php echo $_SESSION['User_Id']; ?>">Change password</a></button>
            </div>
            <button class="btn1 btn-danger p-0  mt-3"><a href="./user/logout.php?logout_user=<?php echo $_SESSION['User_Id']; ?>">LogOut</a></button>
            <div class="pb-2 rounded mt-4 date "> <span class="join"><?php echo $date; ?></span> </div>
            <div class="pb-2 rounded mt-4 date "> <a href="./user/disactive.php?id=<?php echo $_SESSION['User_Id'];  ?>">disactive</a> </div>
        </div>
    </div>
</div>
<?php include('./inc/footer.php') ?>
