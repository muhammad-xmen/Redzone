<?php include('./inc/nav.php'); ?>
<?php
redirect('index.php');
?>
<div class="buy">

    <?php
    $query_user = mysqli_query($db, "SELECT * FROM `user` WHERE `name`= '{$_SESSION['UserLogin']}'");
    if ($query_user) {
        $row_user = mysqli_fetch_assoc($query_user);
        $name_user =  $row_user['name'];
        $phone_user = $row_user['phone'];
        $email_user = $row_user['email'];
        $city_user = $row_user['city'];
    }

    if (isset($_GET['buy']) && isset($_SESSION['UserLogin'])) {
        $id = $_GET['buy'];
        $sql = "SELECT * FROM `item` WHERE `id` = '$id'";
        $query = mysqli_query($db, $sql);
        if (mysqli_num_rows($query) > 0) {

            if ($query) {
                while ($row = mysqli_fetch_assoc($query)) {
                    $name = $row['name'];
                    $price = $row['price'];
                    $details = $row['details'];
                    $photo = $row['photo'];
                }
            } else {
                function_alert('هیچ نەدۆزرایەوە');
                header('location:./index.php');
            }
        } else {
            function_alert('هیچ نەدۆزرایەوە');
            header('location:./index.php');
        }
    }

    ?>
    <?php include('./inc/buy.inc.php'); ?>
    <div class="card mb-3 p-4" style="width: 100%;">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="./Admin/upload/<?php echo $photo; ?>" class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8 col-sm-12">
                <div class="card-body">
                    <h5 class="card-title text-center mt-2 fs-3"><?php echo  $name; ?></h5>
                    <p class="card-text text-center mt-5 mb-4"><?php echo $details; ?></p>
                    <p class="card-text ms-5  shadow-sm p-1 fs-5 text-center" style="width:100px;"><small class="text-muted"><?php echo $price; ?>$ </small></p>
                </div>
            </div>
        </div>
    </div>
    <?php if (isset($_POST['buy_item'])) { ?>
        <p class="text-danger text-center"> <?php echo $error['err']; ?></p>
    <?php } ?>
    <div class="container  justify-content-center d-flex">
        <form class="col-lg-5 col-sm-12 " method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="hidden" name='name' value="<?php echo $name ?>" disable>
            <input type="hidden" name='price' value="<?php echo $price ?>" disable>
            <input type="hidden" name='details' value="<?php echo $details ?>" disable>
            <input type="hidden" name='photo' value="<?php echo $photo ?>" disable>
            <input type="hidden" name='name_user' value="<?php echo $name_user ?>" disable>
            <input type="hidden" name='phone_user' value="<?php echo $phone_user ?>" disable>
            <input type="hidden" name='email_user' value="<?php echo $email_user ?>" disable>
            <div class="mb-3">
                <input type="text" name="quantity" class="form-control" placeholder="ژمارەی بەرهەم" <?php if (isset($_POST['buy_item'])) { ?> value="<?php echo $qut; ?>" <?php } ?>>
            </div>
            <div class="mb-3">
                <select name="color_item" id="" class="form-control">
                    <option value="null">رەنگی بەرهەم</option>
                    <option class="black" value="black">black<span></span> </option>
                    <option class="white" value="white">white<span></span> </option>
                    <option class="red" value="red">red<span></span> </option>
                </select>
            </div>
            <div class="mb-5">
                <select name="city_user" id="" class="form-control">
                    <option value="null">شاری نیشتە جێبوون</option>
                    <option value="ranya">رانیە </option>
                    <option value="qaladzy">قەلادزێ</option>
                    <option value="dukan">دووکان</option>
                    <option value="sulaymani">سلێمانی</option>
                    <option value="hawler">هەولێر</option>
                    <option value="karkuk">کەرکوک</option>
                    <option value="dhouk">دهۆک</option>
                </select>
            </div>
            <button type="submit" class="btn" name="buy_item">کرین</button>
        </form>
    </div>

</div>