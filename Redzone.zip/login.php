<?php
include('./inc/nav.php');
include('./inc/login.inc.php');
?>

<div class="login">
    <div class="login-user">
        <div class="msg">
        <?php if(isset($_POST['Login_user'])){?>
            <p class="text-danger"><?php echo $error['err']; ?></p>
            <?php } ?>
        </div>
        <div class="container">
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                <div class="mb-3">
                    <input type="email" name="email" class="form-control" placeholder="ئیمێڵ" <?php if(isset($_POST['Login_user'])){ ?> value="<?php echo $email; ?>" <?php } ?>>
                </div>
                <div class="mb-3">
                    <input type="password" name="password" class="form-control" placeholder="وشەی نهێنی">
                </div>
                <button type="submit" name="Login_user" class="btn_login">چوونەژورەوە</button>
            </form>
            <p class="text-center">ئەگەر ئەکاونتت نیە <a href="register.php" class="register">خۆت تۆماربکە</a> </p>
        </div>
    </div>
</div>
<?php include('./inc/footer.php'); ?>