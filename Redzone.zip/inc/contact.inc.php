<?php
// Replace this with your own email address
$to = 'ihama9768@gmail.com';
$error['err'] = '';
if (isset($_POST['send'])) {

    $name = clear($_POST['name']);
    $email = clear($_POST['email']);
    $subject = clear($_POST['subject']);
    $contact_message = clear($_POST['message']);
    if (empty($name) && empty($subject) && empty($email) && empty($contact_message)) {
        $error['err'] = 'خانەکان پر بکەرەوە';
    }elseif(empty($name)){
        $error['err'] = ' تکایە ناوت بنووسە';
    }else if(empty($email)){
        $error['err'] = ' تکایە ئیمێلەکەت  بنووسە';
    }else if(empty($subject)){
        $error['err'] = ' تکایە ناوی بابەتەکەت  بنووسە';
    }else if(empty($contact_message)){
        $error['err'] = ' تکایە دەربارەی  بابەت  بنووسە';
    }else{
        //echo 'send';
        $formcontent ="From: $name \n Message: $contact_message";
        $header = "From: $email \r\n";
       $send = mail($to, $subject, $formcontent, $header) or die("Error!");
        if($send == true){
            $_SESSION['status']='دەست خۆش بۆ پەیوەندی کردنەکە';
            $_SESSION['status-code']='success';
            header('Location:indedx.php');
        }
    }

    // // Set Message
    // $message .= "Email from: " . $name . "<br />";
    // $message .= "Email address: " . $email . "<br />";
    // $message .= "Message: <br />";
    // $message .= nl2br($contact_message);
    // $message .= "<br /> ----- <br /> This email was sent from your site " . url() . " contact form. <br />";

    // // Set From: header
    // $from =  $name . " <" . $email . ">";

    // // Email Headers
    // $headers = "From: " . $from . "\r\n";
    // $headers .= "Reply-To: " . $email . "\r\n";
    // $headers .= "MIME-Version: 1.0\r\n";
    // $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

    // ini_set("sendmail_from", $to); // for windows server
    // $mail = mail($to, $subject, $message, $headers);

    // if ($mail) {
    //     echo "OK";
    // } else {
    //     echo "Something went wrong. Please try again.";
    // }
}
