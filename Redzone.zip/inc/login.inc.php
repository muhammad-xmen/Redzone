<?php
$error['err'] = '';
if (isset($_POST['Login_user'])) {
    //echo 'done';
    $email = clear($_POST['email']);
    $password = clear($_POST['password']);
    if (empty($email) && empty($password)) {
        $error['err'] = 'خانەکان پربکەرەوە';
    } else if (empty($email)) {
        $error['err'] = 'ئیمێڵ داخڵ بکە';
    } else if (empty($password)) {
        $error['err'] = 'وشەی نهێنی داخڵ بکە';
    } else {
        $query_check = mysqli_query($db, "SELECT * FROM `user` WHERE `email` = '$email' ");
        $row_check = mysqli_num_rows($query_check);
        if ($row_check > 0) {
            //echo 'haya';
            $row = mysqli_fetch_array($query_check);
            if (password_verify($password, $row['password'])) { //agar password rast bw
                //echo 'done';
                $_SESSION['status'] = $row['name']  . 'بەخێربێت';
                $_SESSION['status-code'] = 'success';
                $_SESSION['UserLogin'] = $row['name'];
                $_SESSION['User_Id'] = $row['user_id'];
                header('Location:index.php');
            } else {
                $error['err'] = 'وشەی نهێنی هەڵەیە';
            }
        } else {
            $error['err'] = 'هیچ کەسێک نەدۆزرایەوە';
        }
    }
}
