<div class="row pe-5 ps-5 footer" >
    <p class="text-center">&copy;2021 Muhammad All rights reserved</p>
    <p class="text-right"><?php row_visitor('visitors'); ?> :
        
    ریژەی سەردان کەر</p>
</div>
<script src="./assets/js/app.js"></script>
<script src="./assets/js/sweetalert.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>