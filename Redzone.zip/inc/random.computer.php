<div class="row  justify-content-center  ">
    <?php
    $query_random = mysqli_query($db, "SELECT * FROM `item` WHERE `id` !=' $id'  ORDER BY  RAND() LIMIT 4  ");
    if ($query_random) {
        $i = 0;
        while ($row = mysqli_fetch_array($query_random)) {
            $id_rand = $row['id'];
            $name_rand = $row['name'];
            $price_rand = $row['price'];
            $photo_rand = $row['photo'];
    ?>
            <div class="card home m-5" style="width: 16rem; height:25rem;position:relative;">
                <img src="./Admin/upload/<?php echo $photo_rand; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title text-center p-2 fs-4"><?php echo  $name_rand; ?></h5>
                    <!-- <p class="card-text text-justify "><?php echo $details; ?></p>  -->
                    <p class="card-text text-left"><?php echo $price_rand; ?>$</p>
                    <div class="bottom">
                        <a href="view.php?id=<?php echo $id_rand; ?>"><i class="fas fa-eye me-2"></i>بینینی بەرهەم</a>
                        <a href="buy.php?buy=<?php echo $id_rand; ?>"><i class='bx bxs-shopping-bag me-2'></i>کرین</a>
                    </div>
                </div>

            </div>
    <?php
            $i++;
        }
    }
    ?>
</div>