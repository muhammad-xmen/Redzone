<?php

session_start();

$host_name = 'localhost';
$user_name = 'root';
$db_name = 'shopping2';
$db = mysqli_connect($host_name, $user_name, '', $db_name);
if (!$db) {
    mysqli_connect_error($db);
    echo "داتا بەیس کۆنێکت نییە";
}
function bootstrap()
{
    echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"  rel="stylesheet">';
}
function function_alert($message)
{
    // Display the alert box 
    echo "<script>alert('$message');</script>";
}
function clear($data)
{
    global $db;
    $data = htmlspecialchars($data);
    $data = mysqli_real_escape_string($db, $data);
    $data = trim($data);
    $data = stripslashes($data);
    return $data;
}

function redirect($Where)
{
    if (!isset($_SESSION['UserLogin'])) {
        $_SESSION['status'] = 'تکایە خۆت تۆمار بکە یان بچۆ ژورەوە بۆ کرینی بابەت';
        $_SESSION['status-code'] = 'error';
        header('Location:' . $Where . '');
    }
}

$ip = $_SERVER['REMOTE_ADDR']; // awa taybata ba ip
$query = mysqli_query($db, "SELECT * FROM `visitors` WHERE `ip` ='$ip'");
if (mysqli_num_rows($query) == 0) {
    $query = mysqli_query($db, "INSERT INTO `visitors` SET `ip`='$ip' ");
}

function row_visitor($condition){
    global $db;
    $query = mysqli_query($db,"SELECT * FROM $condition ");
    echo  mysqli_num_rows($query);
}