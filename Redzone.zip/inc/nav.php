<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta description="لێرانە دەتوانی کاێکان بە نرخێکی هەرزان و ئاسان بکڕی  ">
    <title>RedZone</title>
    <link rel="stylesheet" href="./assets/css/style.css">
    <link rel="stylesheet" href="./assets/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <?php bootstrap(); ?>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<body>
    <?php if (isset($_SESSION['status']) && isset($_SESSION['status-code'])) {  ?>
        <script>
            swal({
                title: "<?php echo $_SESSION['status']; ?>",
                // text: "You clicked the button!",
                icon: "<?php echo $_SESSION['status-code']; ?>",
            });
        </script>
    <?php
        unset($_SESSION['status']);
        unset($_SESSION['status-code']);
    }
    ?>
    <nav class="navbar navbar-expand-lg navbar-light " >
        <div class="container-fluid ">
            <a class="navbar-brand fs-4 ms-3" href="index.php">Red<span class="text-danger">Zone</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="far fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse fs-5" id="navbarSupportedContent" >
                <ul class="navbar-nav m-auto   mb-lg-0" dir="rtl">
                    <li class="nav-item">
                        <a class="nav-link active" href="./index.php">سەرەتا</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active" href="computer.php">کۆمپیوتەر</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active" href="mobile.php">مۆبایل</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active" href="contact.php">پەیوەندی کردن</a>
                    </li>
                </ul>
                <?php if (!isset($_SESSION['UserLogin']) && !isset($_SESSION['userid'])) { ?>
                    <li class="nav-item me-3 "><a href="login.php " class="btn btn-primary text-black d-flex justify-content-center align-items-lg-center"><i class="fal fa-sign-in-alt me-2"></i>چوونەژورەوە</a></li>
                <?php  } else { ?>
                    <a href="profile.php?user_id=<?php echo $_SESSION['User_Id']; ?>" class="profile me-4" type="button" id="profileBtn"><i class="fas fa-user-alt"></i></a>
                    <!-- <button class="btn1 btn-danger m-1"><a href="./user/logout.php?logout_user?<?php echo  $_SESSION['User_Id']; ?>">LogOut</a></button>  -->
                <?php  } ?>
            </div>
        </div>
    </nav>