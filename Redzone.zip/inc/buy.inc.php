<?php
$error['err'] = '';
if (isset($_POST['buy_item']) && $_SESSION['UserLogin']) {
    //echo 'done';
    $qut = clear($_POST['quantity']);
    $color = clear($_POST['color_item']);
    $name = clear($_POST['name']);
    $price = clear($_POST['price']);
    $photo = clear($_POST['photo']);
    $name_user = clear($_POST['name_user']);
    $phone_user = clear($_POST['phone_user']);
    $email_user = clear($_POST['email_user']);
    $city_user = clear($_POST['city_user']);
    $photo_user = clear($_POST['photo_user']);
    $date = date('Y-m-d h:i');
    $total_price = (int)$price * (int)$qut;
    $status = "not-order";
    if (empty($qut) && $color == 'null' && $city_user == 'null') {
        $_SESSION['status'] = 'دوبارە هەوڵبدەرەوە';
        $_SESSION['status-code'] = 'error';
        header('Location:index.php');
    } elseif (empty($qut)) {
        $error['err'] = 'ژمارەی بەرهەم بنووسە';
    } elseif ($color == 'null') {
        $error['err'] = ' رەنگی بەرهەم دیاری بکە';
    } else if (!is_numeric($qut)) {
        $error['err'] = 'ژمارەی بەرهەم بنووسە';
    } else if ($city_user == 'null') {
        $error['err'] = 'شوێنی نیشتە جێبوون دیاری بکە ';
    } else {
        $sql_order = " INSERT INTO `order_user`(`name_user`,`request`,  `phone_user`, `email_user`, `city_user`, `date`, `color_item`, `photo`, `quantity`, `total_item_price`) VALUES ('$name_user','$status',' $phone_user','$email_user','$city_user','$date','$color','$photo ','$qut','$total_price') ";
        $query_order = mysqli_query($db, $sql_order);
        if ($query_order == true) {
            //echo 'done';
            $_SESSION['status'] = 'بە زوترین کات کاڵاکات داگاتە دەست';
            $_SESSION['status-code'] = 'success';
            header('Location:index.php');
        } else {
            //echo 'fail';
            $_SESSION['status'] = 'دوبارە هەوڵبدەرەوە';
            $_SESSION['status-code'] = 'error';
            header('Location:index.php');
        }
    }
}
