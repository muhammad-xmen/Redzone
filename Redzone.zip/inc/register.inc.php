<?php
$error['err'] = '';
if (isset($_POST['register_user'])) {
    //echo 'done';
    $firstname = clear($_POST['firstName']);
    $lastName = clear($_POST['lastName']);
    $full_name = $firstname . $lastName;
    $user_id = rand() . rand();
    $phone = clear($_POST['number_phone']);
    $gender = clear($_POST['gender']);
    $city  = clear($_POST['city']);
    $email  = clear($_POST['email']);
    $date = date("Y-m-d");
    $password = clear($_POST['password']);
    $password_conf  = clear($_POST['password_con']);
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $file = $_FILES['image'];
    $fileName = $_FILES['image']['name'];
    $fileType = $_FILES['image']['type'];
    $fileTmpName = $_FILES['image']['tmp_name'];
    $fileError = $_FILES['image']['error'];
    $fileSize = $_FILES['image']['size'];
    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));
    $fileAllowedextensions = array('jpg', 'jpeg', 'png', 'gif', 'svg');

    if (empty($firstname) && empty($lastName) && empty($phone) && empty($email) && empty($password) && empty($password_conf) && empty($city)) {
        $error['err'] = 'تکایە خانەکان پربکەوە';
    } else if (empty($firstname)) {
        $error['err'] = 'ناوت بنووسە';
    } elseif (!preg_match("/^[a-zA-z]*$/", $firstname) && !preg_match("/^[a-zA-z]*$/", $lastName)) {
        $error['err'] = 'ناوت بە ئنگلیزی بنووسە';
    } else if (empty($lastName)) {
        $error['err'] = 'ناوی بابت بنووسە';
    } elseif (empty($phone)) {
        $error['err'] = 'ژمارەی مۆبایل داخڵ بکە';
    } elseif (empty($city)) {
        $error['err'] = 'ناوی شارەکەت بنووسە';
    } elseif ($gender == 'null') {
        $error['err'] = ' رەگەزت دیاری بکە';
    } elseif (empty($email)) {
        $error['err'] = 'ئیمێڵ بنووسە';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error['err'] = 'ئیمێڵ گونجاو نیە';
    } elseif (empty($password) && empty($password_conf)) {
        $error['err'] = 'وشەی نهێنی داخڵبکە';
    } else if (strlen($password) < 8) {
        $error['err'] = 'وشەی نهێنی لاوازە';
    } elseif ($password != $password_conf) {
        $error['err'] = ' دڵنیابەرەوە لە وشەی نهێنی ';
    } else {
        //echo 'done';
        $query_email = mysqli_query($db, "SELECT * FROM `user` WHERE `email`='$email'");
        if (mysqli_num_rows($query_email) > 0) {
            $error['err'] = 'ئیمێڵ گونجاو نیە';
        } else {
            if (in_array($fileActualExt, $fileAllowedextensions)) { //agar true bw
                if ($fileError === 0) {
                    if ($fileSize < 10000000) { //file size hata 10 mb qbwle dakat dana dabeta else
                        $fileNewname = rand() . rand() . "." . $fileActualExt; // lera naweke taza bo imgaka dadanen 1 rand nawakayate 2 .dot 
                        $filefrom = "./user/upload/$fileNewname"; // amayan bo awa bakar det bman bat bo kwe yan rmaka lawe upload bkat
                        move_uploaded_file($fileTmpName, $filefrom); //amash bo move krdny img
                        $sql = "INSERT INTO `user` SET 
                            `name` = '$full_name',
                            `phone` = '$phone',
                            `city`='$city',
                            `date`='$date',
                            `email`='$email',
                            `password`= '$password_hash',
                            `gender`='$gender',
                            `photo`= '$fileNewname',
                            `user_id` = '$user_id' 
                            ";
                        $query = mysqli_query($db, $sql);
                        if ($query) {
                            // echo 'done';
                            $_SESSION['status'] = "بە سەرکەوتوی ئەکاونتت دروست کرد";
                            $_SESSION['status-code'] = "success";
                            $_SESSION['UserLogin'] = $full_name;
                            $_SESSION['User_Id'] = $user_id;
                            header('Location:index.php');
                        } else {
                            $_SESSION['status'] = "دوبارە هەوڵبدەرەوە";
                            $_SESSION['status-code'] = "error";
                            header('Location:register.php');
                        }
                    } else {
                        $error['err'] = 'قەبارەی وێنەکە گەورەیە وێنەیەکی تر تاقیبکەوە ';
                    }
                } else {
                    $error['err'] = 'وێنەیەکی تر هەڵبژێرە';
                }
            } else {
                $error['err'] = 'وێنەیەک دیاریبکە';
            }
        }
    }
}
