-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2021 at 02:39 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `admin_id` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `num_phone` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `role` varchar(100) NOT NULL COMMENT '1 bo superadmin || 2 bo admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `admin_id`, `username`, `num_phone`, `email`, `password`, `role`) VALUES
(20, 'darya sidra', '1557407090701004898755972865', 'darya_12', '5222222222', 'darya@gmail.com', '$2y$10$WCujMNMPkM7CPPUiONW.luGXDOyxsC0WfVt6OONMghQnaA0mGIrfC', 'Admin'),
(21, 'muhammad', '3201950283823626681330594176', 'Hamo_12', '07501842910', 'muhammad@gmail.com', '$2y$10$SjSmaviFKpSnG/F3GYi8ougu26wM3GjOuw8tR0KSYFf7qcQpxq.vO', 'SuperAdmin');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `price` varchar(100) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `type_item` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `name`, `details`, `price`, `photo`, `type_item`) VALUES
(11, 'hp notebook', 'PROCESSOR Intel Core i5-1038NG7, PROCESSOR speed 2GHz,RAM 16 GB , Hard 512 GB ssd ,color black', '1100', '1854718202092858647.jpg', 'computer'),
(15, 'vivo v19', 'Display 6.44-inch (1080x2400) ,Processor Qualcomm Snapdragon 712,rnFront Camera (32MP + 8MP),Rear Camera (48MP + 8MP + 2MP + 2MP),RAM 8GB  ,Storage 128GB ,Battery Capacity 4500mAh ,OSrnAndroid 10', '300', '2717491421918807753.webp', 'mobile'),
(16, 'HP Laptop 15s', 'processer AMD Ryzen™ 5 processor ,  operant systems Windows 10 Home 64,rnhard 512 GB PCIe NVMe M.2 SSD, screen size 15.6 inc, Up to 9 hours and 30 minutes ,1 SuperSpeed USB Type-C 5Gbps signaling rate; 2 SuperSpeed USB Type-A 5Gbps signaling rate; 1 HDMI ', '1000', '1284771848264493793.png', 'computer'),
(17, 'HP ProBook 635 Aero', 'AMD Ryzen™ 5 processorrnWindows 10 Pro 64rn13.3&quot; diagonal, FHD (1920 x 1080), IPS, anti-glare, 250 nits, 45% NTSCrn8 GB DDR4-3200 MHz RAM (1 x 8 GB)rn512 GB PCIe® NVMe™ SSDrnEasy to carry, and ready for businessrnAMD Radeon™ Graphicsrn1 SuperSpeed US', '1500', '151525895221670191.png', 'computer'),
(18, 'Windows Laptop', '15.6 inch 8GB RAM DDR4 256GB M.2 SSD Notebook Computers, Intel J4125Quad-Core Computer Laptop, 1080P IPS Windows10 Pro PC Laptops, Full Size Keyboard', '2000', '18269288121933335888.jpg', 'computer');

-- --------------------------------------------------------

--
-- Table structure for table `order_user`
--

CREATE TABLE `order_user` (
  `id` int(11) NOT NULL,
  `name_user` varchar(255) NOT NULL,
  `phone_user` varchar(255) NOT NULL,
  `email_user` varchar(200) NOT NULL,
  `city_user` varchar(150) NOT NULL,
  `date` varchar(150) NOT NULL,
  `color_item` varchar(100) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `quantity` varchar(200) NOT NULL,
  `total_item_price` varchar(200) NOT NULL,
  `request` varchar(200) NOT NULL COMMENT 'bary dawakaryaka'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_user`
--

INSERT INTO `order_user` (`id`, `name_user`, `phone_user`, `email_user`, `city_user`, `date`, `color_item`, `photo`, `quantity`, `total_item_price`, `request`) VALUES
(10, 'muhammadismail', ' 07501842910', 'Muhammad@gmail.com', 'hawler', '2021-10-14 10:16', 'red', '1854718202092858647.jpg ', '3', '3000', 'not-order'),
(11, 'muhammadismail', ' 07501842910', 'Muhammad@gmail.com', 'dukan', '2021-10-14 10:17', 'black', '1854718202092858647.jpg ', '10', '10000', 'ordered'),
(12, 'muhammadismail', ' 07501842910', 'Muhammad@gmail.com', 'qaladzy', '2021-10-14 10:18', 'white', '1854718202092858647.jpg ', '12', '12000', 'ordered'),
(13, 'daryasidra', ' 07510124084', 'darya@gmail.com', 'ranya', '2021-10-14 12:29', 'black', '1854718202092858647.jpg ', '12', '12000', 'ordered'),
(15, 'daryasidra', ' 07510124084', 'darya@gmail.com', 'ranya', '2021-10-14 12:31', 'red', '1854718202092858647.jpg ', '3', '3000', 'ordered'),
(16, 'ahmad hasan', ' 07510124084', 'ahmad@gmail.com', 'qaladzy', '2021-10-14 08:41', 'black', '1854718202092858647.jpg ', '4', '4800', 'not-order'),
(17, 'muhammad ismail', ' 07501842910', 'muhammad@gmail.com', 'sulaymani', '2021-10-15 09:32', 'black', '151525895221670191.png ', '12', '18000', 'not-order'),
(18, 'muhammad ismail', ' 07501842910', 'muhammad@gmail.com', 'ranya', '2021-10-15 09:37', 'black', '2717491421918807753.webp ', '12', '3600', 'not-order'),
(19, 'muhammad ismail', ' 07501842910', 'muhammad@gmail.com', 'ranya', '2021-10-15 09:39', 'black', '18269288121933335888.jpg ', '1', '2000', 'not-order'),
(20, 'muhammad ismail', ' 07501842910', 'muhammad@gmail.com', 'sulaymani', '2021-10-15 02:29', 'black', '151525895221670191.png ', '12', '18000', 'not-order'),
(21, 'muhammad ismail', ' 07501842910', 'muhammad@gmail.com', 'ranya', '2021-10-15 02:31', 'black', '151525895221670191.png ', '1', '1500', 'not-order');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `date` varchar(100) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(200) NOT NULL,
  `gender` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `user_id`, `phone`, `photo`, `city`, `date`, `email`, `password`, `gender`) VALUES
(14, 'muhammad ismail', '999261784812958392', '07501842910', '9922040171809732664.jpg', 'ranya', '2021-10-15', 'muhammad@gmail.com', '$2y$10$CIRTH8UhFAkVvnzDB9bTa.OPSQ4ekHb/XfI64y4nF4fpAM8I1OuPe', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `ip`) VALUES
(1, '0'),
(3, '192.168.1.11'),
(4, '192.168.1.178'),
(6, '192.168.1.213'),
(2, '::1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_user`
--
ALTER TABLE `order_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ip` (`ip`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `order_user`
--
ALTER TABLE `order_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
