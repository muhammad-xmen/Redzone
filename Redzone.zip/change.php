<?php include('./inc/nav.php'); ?>
<?php
redirect('index.php');
?>
<?php
if (isset($_SESSION['User_Id'])) {
    $user_id =$_SESSION['User_Id'];
    $sql = "SELECT * FROM `user` WHERE `user_id` = '$user_id'";
    $query = mysqli_query($db, $sql);
    if ($query) {
        // echo 'data haya';
        $row = mysqli_fetch_array($query);
        $id = $row['id'];
    } else {
        echo 'data nya';
    }
}
?>
<?php include('./user/change.php'); ?>
<div class="container p-5 mt-5 change">
    <div class="row justify-content-center">
        <?php if (isset($_POST['change'])) { ?>
            <p class="text-danger text-center m-4"><?php echo $error['err'];  ?></p>
        <?php } ?>
        <form class=" col-lg-6 col-sm-10" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="mb-3">
                <input type="hidden" name="id" class="form-control" value="<?php echo $id; ?>">
            </div>
            <div class="mb-3">
                <input type="password" name="currentPassword" class="form-control p-3 fs-5" placeholder="وشەی نهێنی ئێستات">
            </div>
            <div class="mb-3">
                <input type="password" name="newPassword" class="form-control p-3 fs-5" placeholder="وشەی نهێنی نوێ">
            </div>
            <div class="mb-3">
                <input type="password" name="confirmPassword" class="form-control p-3 fs-5" placeholder=" دوبارە کردنەوەی وشەی نهێنی نوێ">
            </div>
            <div class="row  mt-5">
                <button type="submit" class="btn btn-primary w-50 m-auto p-2 fs-5 " name="change">Change</button>
            </div>
        </form>
    </div>
</div>





<?php include('./inc/footer.php'); ?>