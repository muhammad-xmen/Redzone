<?php include './inc/nav.php';  ?>
<div class="buy">
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = mysqli_query($db, "SELECT * FROM `item`WHERE `id`='$id' ");
        if ($query) {
            while ($row = mysqli_fetch_array($query)) {
                $id = $row['id'];
                $name = $row['name'];
                $details = $row['details'];
                $price = $row['price'];
                $photo = $row['photo'];
            }
        }
    }
    ?>
    <div class="card mb-3 p-4" style="width: 100%;">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="./Admin/upload/<?php echo $photo; ?>" class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8 col-sm-12">
                <div class="card-body">
                    <h5 class="card-title text-center mt-2 fs-3"><?php echo  $name; ?></h5>
                    <p class="card-text text-center mt-5 mb-4"><?php echo $details; ?></p>
                    <p class="card-text ms-5  shadow-sm p-1 fs-5 text-center" style="width:100px;"><small class="text-muted"><?php echo $price; ?>$ </small></p>
                </div>
                <div class="row col-lg-6 m-auto">
                    <a href="buy.php?buy=<?php echo $id; ?>" class="btn  d-flex justify-content-center align-items-center"><i class='bx bxs-shopping-bag me-2'></i>کرین</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('./inc/random.computer.php'); ?>
<?php include './inc/footer.php';  ?>