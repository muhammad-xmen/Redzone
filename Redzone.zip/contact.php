<?php include('./inc/nav.php'); ?>
<?php include('./inc/contact.inc.php');
?>
<style>
    ::placeholder {
        text-align: right !important;
    }
</style>

<body>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 text-center ">
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10 col-md-12">
                    <div class="wrapper">
                        <div class="row no-gutters">
                            <div class="col-md-7 d-flex align-items-stretch">
                                <div class="contact-wrap w-100 p-md-5 p-4">
                                    <h3 class="mb-4 text-center"> پەیوەندی کردن</h3>
                                    <?php if (isset($_POST['send'])) { ?>
                                        <div class="row text-center">
                                            <p class="mb-5 text-danger"><?php echo  $error['err']; ?></p>
                                        </div>
                                    <?php } ?>
                                    <form method="POST" id="contactForm" name="contactForm" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="name" id="name" placeholder="ناو" <?php if (isset($_POST['send'])) { ?> value="<?php echo $name; ?>" <?php } ?>>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="email" class="form-control" name="email" id="email" placeholder="ئیمێڵ" <?php if (isset($_POST['send'])) { ?> value="<?php echo $email; ?>" <?php } ?>>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="subject" id="subject" placeholder="بابەت" <?php if (isset($_POST['send'])) { ?> value="<?php echo $subject; ?>" <?php } ?>>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <textarea name="message" class="form-control" id="message" cols="30" rows="7" placeholder="دەربارەی بابەت"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-md-12" >
                                                <div class="form-group text-right p-2" >
                                                    <input type="submit" value="ناردنی نامە" name="send" class="btn btn-primary fs-5 p-2">
                                                    <div class="submitting"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-5 d-flex align-items-stretch">
                                <div class="info-wrap bg-primary w-100 p-lg-5 p-4">
                                    <h3 class="mb-5 mt-md-4 text-center">پەیوەندی کردن بە ئێمەوە لە ریگای</h3>
                                    <div class="dbox mt-4 w-100 d-flex align-items-center">
                                        <div class="icon d-flex align-items-center justify-content-center">
                                            <span class="fa fa-phone"></span>
                                        </div>
                                        <div class="text pl-3 fs-5">
                                            <p><span>Phone:</span> <a href="tel://07501842910" target="_blank">07501842910</a></p>
                                        </div>
                                    </div>
                                    <div class="dbox w-100 d-flex align-items-center">
                                        <div class="icon d-flex align-items-center justify-content-center">
                                            <span class="fa fa-paper-plane"></span>
                                        </div>
                                        <div class="text pl-3 fs-5">
                                            <p><span>Email:</span> <a href="ihama9768@gmail.com" target="_blank">ihama9768@gmail.com</a></p>
                                        </div>
                                    </div>
                                    <div class="dbox w-100 d-flex align-items-center">
                                        <div class="icon d-flex align-items-center justify-content-center">
                                            <i class="fab fa-facebook fs-2"></i>
                                        </div>
                                        <div class="text pl-3 fs-5">
                                            <p><span>facebook:</span> <a href="https://www.facebook.com/Muhammad.1ismail.12/" target="_blank">Ha Ma</a></p>
                                        </div>
                                    </div>

                                    <div class="dbox w-100 d-flex align-items-center">
                                        <div class="icon d-flex align-items-center justify-content-center">
                                            <i class="fab fa-snapchat fs-2"></i>
                                        </div>
                                        <div class="text pl-3 fs-5">
                                            <p><span>snapchat:</span> <a href="https://www.snapchat.com/add/ha-ma1111?fbclid=IwAR0vHgOv_ixE4kxPmtS0cUipeGs4a3ch913pOJadhjS4MmLPiGNK8w-E8gU" target="_blank">ha-ma1111</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php include('./inc/footer.php') ?>