// const btntoggle = document.querySelector('.toggle');
// const navbar = document.querySelector('.navbar');
// btntoggle.addEventListener('click', () => {
//     navbar.classList.toggle('active');
//     if (btntoggle) {
//         btntoggle.classList.toggle('fa-times');
//     }
// })
// // if scroll nav remove active
// window.onscroll = function () {
//     navbar.classList.remove('active');
//     btntoggle.classList.remove('fa-times');
// }

// const navLink = document.querySelectorAll(".nav-link");

// navLink.forEach(n => n.addEventListener("click", closeMenu));

// function closeMenu() {
//     hamburger.classList.remove("active");
//     navMenu.classList.remove("active");
// }
