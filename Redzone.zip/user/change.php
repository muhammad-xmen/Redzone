<?php
$error['err'] = '';
redirect('index.php');

if (isset($_POST['change'])) {
    // echo 'done';
    $id = clear($_POST['id']);
    $currentPassword = clear($_POST['currentPassword']);
    $newPassword = clear($_POST['newPassword']);
    $confirmPassword = clear($_POST['confirmPassword']);

    $sql = "SELECT * FROM `user` WHERE `password` = '$currentPassword' ";
    $query = mysqli_query($db, $sql);
    if (empty($currentPassword) && empty($newPassword) && empty($confirmPassword)) {
        $_SESSION['status'] = 'دەستکاری وشەی نهێنی نەکرا';
        $_SESSION['status-code'] = 'warning';
        header("Location:index.php");
    }
    if (empty($currentPassword)) {
        $error['err'] = 'خانەکان پربکەرەوە';
    } else if (empty($newPassword)) {
        $error['err'] = 'وشەی نهێنی نوێ بنووسە';
    } else if ($newPassword !== $confirmPassword) {
        $error['err'] = ' دڵنیابەرەوە لە وشەی نهێنی';
    } else {
        $sql = "SELECT * FROM `user` WHERE `id`='$id'";
        $result = mysqli_query($db, $sql);
        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_array($result);
            if ($currentPassword !== $row['password']) {
                echo 'FAIL';
            } 
                $hash_newpassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $sql_2 = "UPDATE `user` SET `password`='$hash_newpassword' WHERE `id`='$id' ";
                mysqli_query($db, $sql_2);
                $_SESSION['status'] = ' بە سەرکەوتووی دەستکاری کرا';
                $_SESSION['status-code'] = 'success';
                header('Location:index.php');
        } else {
            $error['err'] = '! دڵنیابەرەوە لە وشەی نهێنی';
        }
    }
}
