<?php include('../inc/config.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $Getimg = mysqli_query($db, "SELECT * FROM `user` WHERE `user_id`='$id'");
    while ($row = mysqli_fetch_assoc($Getimg)) {
        $img = $row["photo"];
    }
    unlink("./upload/$img");
    $query_delete = mysqli_query($db, "DELETE FROM `user` WHERE `user_id` ='$id'");
    if ($query_delete) {
        $id =  $_SESSION['User_Id'];
        session_unset();
        session_destroy();
        unset($id);
        header('Location:../index.php');
    } else {
        $_SESSION['status'] = '! ناتوانی ئەکاونت رەشبکەیەوە';
        $_SESSION['status-code'] = 'error';
        header('Location:../index.php');
    }
}
