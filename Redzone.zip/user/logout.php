<?php
session_start();
if (isset($_GET['logout_user'])) {
    $id =  $_SESSION['User_Id'];
    session_unset();
    session_destroy();
    unset($id);
    header('location:../index.php');
}
