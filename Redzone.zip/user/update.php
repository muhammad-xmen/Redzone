<?php
if (isset($_POST['update'])) {
   $id  = clear($_POST['id']);
   $Newname = clear($_POST['Newname']);
   $Newphone = clear($_POST['Newphone']);
   $Newemail = clear($_POST['Newemail']);
   $Newcity = clear($_POST['Newcity']);
   if (empty($Newname) || empty($Newemail) || empty($Newcity) || empty($Newphone)) {
      $_SESSION['status'] = 'Profile not changed!';
      $_SESSION['status-code'] = 'error';
      header('Location:index.php');
   } else {
      $query_update = mysqli_query($db, " UPDATE  `user` 
         SET
         `name` = '$Newname',    
         `phone` = '$Newphone',    
         `city` = '$Newcity',    
         `email` = '$Newemail' 
         WHERE `id`= '$id'   
      ");
      if ($query_update) {
         $_SESSION['UserLogin'] = $Newname;
         $_SESSION['status'] = 'Profile has been changeded !';
         $_SESSION['status-code'] = 'success';
         header('Location:index.php');
      }
   }
}
