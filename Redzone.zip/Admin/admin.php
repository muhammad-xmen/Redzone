<?php include './inc/nav.php';  ?>
<div class="heading">
    <div class="head">
        <p>بەرێوبەر</p>
        <?php if (isset($_SESSION['superadmin'])) { ?>
            <a href="./add/admin.php"><i class='bx bxs-user-plus fs-3 text-white me-2'></i>زیادکردنی بەرێوبەر</a>
        <?php } ?>
    </div>
</div>
<?php require('./inc/update.php'); ?>
<div class="row p-1 justify-content-center">
    <?php
    $sql = "SELECT * FROM `admin` ";
    $query = mysqli_query($db, $sql);
    if (mysqli_num_rows($query) > 0) {
        while ($row = mysqli_fetch_assoc($query)) {
            $id = $row['id'];
            $name = $row['name'];
            $username = $row['username'];
            $email = $row['email'];
            $phone = $row['num_phone'];
    ?>
            <?php require('./modal/admin.php'); ?>
            <div class="box-admin">

                <div class="head ">
                    <p class=""><?php echo $name ?></p>
                    <p><?php echo $username ?></p>
                </div>
                <div class="bottom">
                    <?php if (isset($_SESSION['superadmin'])) { ?>
                        <a data-bs-toggle="modal" data-bs-target="#update<?php echo $id; ?>"><i class="fal fa-user-edit fs-3"></i></a>
                        <a href="./inc/delete.php?admin=<?php echo $id; ?>"><i class="fal fa-user-times fs-3"></i></a>
                    <?php } ?>

                    <a data-bs-toggle="modal" data-bs-target="#view<?php echo $id; ?>"><i class="fal fa-address-book fs-3"></i></a>
                </div>
            </div><?php }
            } else {
                echo '<div class="text-center text-danger fs-4">هیچ داتایەک نیە</div>';
            } ?>
</div>
<?php include './inc/footer.php';  ?>