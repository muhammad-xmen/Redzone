<?php require('config.php'); ?>
<?php
if (!isset($_SESSION['superadmin']) && !isset($_SESSION['admin'])) {
  $_SESSION['not-login'] = '<div class="text-danger text-center">ئیمێڵ و وشەی نهێنی داخڵ بکە بۆ چوونەژورەوە</div>';
  header('Location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin</title>
  <link rel="stylesheet" href="./assets/css/style.css">
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <?php bootstrap(); ?>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

<body>
  <?php if (isset($_SESSION['status']) && isset($_SESSION['status-code'])) {  ?>
    <script>
      swal({
        title: "<?php echo $_SESSION['status']; ?>",
        // text: "You clicked the button!",
        icon: "<?php echo $_SESSION['status-code']; ?>",
      });
    </script>
  <?php
    unset($_SESSION['status']);
    unset($_SESSION['status-code']);
  }
  ?>
  <nav class="navbar navbar-expand-lg navbar-light ">
    <div class="container-fluid ">
      <a class="navbar-brand fs-4" href="index.php">Admin Panel</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <i class="far fa-bars"></i>

      </button>
      <div class="collapse navbar-collapse fs-5" id="navbarSupportedContent">
        <ul class="navbar-nav m-auto   mb-lg-0" dir="rtl">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">سەرەتا</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="admin.php">بەرێوبەر</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="computer.php">کۆمپیوتەر</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="mobile.php">مۆبایل</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="order.php">داواکاریەکان</a>
          </li>

        </ul>
        <a href="?logout=<?php if (isset($_SESSION['superadmin_id'])) {
                            echo $_SESSION['superadmin_id'];
                          } elseif (isset($_SESSION['admin_id'])) {
                            echo   $_SESSION['admin_id'];
                          } ?>" class="btn text-white logout fs-5"><i class="fal fa-sign-out-alt"></i> دەرچوون</a>
      </div>
    </div>
  </nav>