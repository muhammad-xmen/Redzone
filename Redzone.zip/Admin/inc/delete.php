<?php include('config.php'); ?>
<?php
if (isset($_GET['admin']) && isset($_SESSION['superadmin'])) {
    $id = $_GET['admin'];
    $sql_de = "SELECT * FROM `admin` WHERE `id` = '$id' && `role`='SuperAdmin'";
    $query_de = mysqli_query($db, $sql_de);
    if (mysqli_num_rows($query_de) == 1) { // agr 1 admin mayawa ba deletem bo naka 
        $_SESSION['status'] = '! ناتوانی بەرێوبەر رەشبکەیەوە ';
        $_SESSION['status-code'] = 'error';
        header("Location:../admin.php");
        // echo 'file';
    } else {
        $sql = "DELETE FROM `admin` WHERE `id` = '$id' && `role`='Admin' ";
        $query = mysqli_query($db, $sql);
        // $row = mysqli_fetch_array($query);
        // if ($row['role'] === 'SuperAdmin') {
        //     $_SESSION['status'] = '! ناتوانی بەرێوبەر رەشبکەیەوە ';
        //     $_SESSION['status-code'] = 'error';
        //     header("Location:../admin.php");
        // } else
        if ($query) {
            //echo 'done';
            $_SESSION['status'] = '! بەرێوبەر رەشکرایەوە';
            $_SESSION['status-code'] = 'success';
            header('Location:../admin.php');
        } else {
            //echo 'fail';
            $_SESSION['status'] = '! بەرێوبەر رەشنەکرایەوە';
            $_SESSION['status-code'] = 'error';
            header('Location:../admin.php');
        }
    }
}
if (isset($_GET['computer']) && isset($_SESSION['superadmin'])) {
    //echo 'done';
    $id = $_GET['computer'];
    // ama bo chek krdne img wa rash krdnaway img la folder uploda agar wana kain rsm rash nabetawa
    $Getimg = mysqli_query($db, "SELECT * FROM `item` WHERE `id`='$id' AND  `type_item`='computer' ");
    while ($row = mysqli_fetch_assoc($Getimg)) {
        $img = $row["photo"];
    }
    unlink("../upload/$img"); //function unlik bakar denen bo srenaway wenaka la folder upload 
    $sql_de = " DELETE FROM `item` WHERE `id` = '$id' ";
    $query = mysqli_query($db, $sql_de);
    if ($query) {
        $_SESSION['status'] = '! بابەت رەشکرایەوە';
        $_SESSION['status-code'] = 'success';
        header('Location:../computer.php');
    } else {
        //echo 'fail';
        $_SESSION['status'] = '! بابەت رەشنەکرایەوە';
        $_SESSION['status-code'] = 'error';
        header('Location:../computer.php');
    }
}
if (isset($_GET['mobile']) && isset($_SESSION['superadmin'])) {
    //echo 'done';
    $id = $_GET['mobile'];
    // ama bo chek krdne img wa rash krdnaway img la folder uploda agar wana kain rsm rash nabetawa
    $Getimg = mysqli_query($db, "SELECT * FROM `item` WHERE `id`='$id' AND  `type_item`='mobile' ");
    while ($row = mysqli_fetch_assoc($Getimg)) {
        $img = $row["photo"];
    }
    unlink("../upload/$img"); //function unlik bakar denen bo srenaway wenaka la folder upload 
    $sql_de = " DELETE FROM `item` WHERE `id` = '$id' ";
    $query = mysqli_query($db, $sql_de);
    if ($query) {
        $_SESSION['status'] = '! بابەت رەشکرایەوە';
        $_SESSION['status-code'] = 'success';
        header('Location:../mobile.php');
    } else {
        //echo 'fail';
        $_SESSION['status'] = '! بابەت رەشنەکرایەوە';
        $_SESSION['status-code'] = 'error';
        header('Location:../mobile.php');
    }
}
?>