<?php
if (isset($_POST['update-admin']) && isset($_SESSION['superadmin'])) {
    //echo 'done';
    $id = $_POST['id'];
    $new_name = clear($_POST['name']);
    $new_username = clear($_POST['username']);
    $new_phone = clear($_POST['phone']);
    if (empty($new_name) || empty($new_username) || empty($new_phone)) {
        $_SESSION['status'] = '! بەێوبەر دەستکاری نەکرا ';
        $_SESSION['status-code'] = 'error';
        header('Location:admin.php');
    } else {
        $sql_update = " UPDATE `admin` SET
         `name`='$new_name' ,
         `username`='$new_username',
         `num_phone`='$new_phone'
          WHERE `id` ='$id' ";
        $query_update = mysqli_query($db, $sql_update);
        if ($query_update == true) {
            //echo 'done';
            $_SESSION['status'] = '! بەێوبەر دەستکاری کرا ';
            $_SESSION['status-code'] = 'success';
            header('Location:admin.php');
        } else {
            // echo 'fail';
            $_SESSION['status'] = '! بەێوبەر دەستکاری نەکرا ';
            $_SESSION['status-code'] = 'error';
            header('Location:admin.php');
        }
    }
}

if (isset($_POST['update-computer'])) {
    // echo 'done';
    $id = clear($_POST['id']);
    $name = clear($_POST['name']);
    $details = clear($_POST['details']);
    $price = clear($_POST['price']);

    if (empty($name) || empty($details) || empty($price)) {
        $_SESSION['update-item'] = '<p class="text-danger">بابەت دەستکاری نەکرا</p>';
        header("Location:computer.php");
    } else {
        $query_update = mysqli_query($db, "UPDATE `item` SET
        `name` ='$name',
        `details` ='$details',
        `price`='$price'
        WHERE `id` = '$id' ");
        if ($query_update) {
            $_SESSION['status'] = '! بابەت دەستکاری کرا ';
            $_SESSION['status-code'] = 'success';
            header("Location:computer.php");
        } else {
            // echo 'fail';
            $_SESSION['status'] = '! بابەت دەستکاری نەکرا';
            $_SESSION['status-code'] = 'error';
            header("Location:computer.php");
        }
    }
}

if (isset($_POST['update-mobile'])) {
    $id = $_POST['id'];
    $name = clear($_POST['name']);
    $details = clear($_POST['details']);
    $price = clear($_POST['price']);
    if (empty($name) || empty($price) || empty($details)) {
        $_SESSION['update'] = '<p class="text-danger">! بابەت دەستکاری نەکرا </p>';
        header('Location:mobile.php');
    } else {
        $sql_update =  " UPDATE  `item` SET
        `name`= '$name',
        `details` ='$details',
        `price` ='$price'
        
        WHERE `id` = '$id'
        ";
        $update_mobile = mysqli_query($db, $sql_update);
        if ($update_mobile) {
            $_SESSION['status'] = '!  بابەت دەستکاری کرا ';
            $_SESSION['status-code'] = 'success';
            header('Location:mobile.php');
        } else {
            $_SESSION['status'] = '! بابەت دەستکاری نەکرا  ';
            $_SESSION['status-code'] = 'error';
            header('Location:mobile.php');
        }
    }
}
