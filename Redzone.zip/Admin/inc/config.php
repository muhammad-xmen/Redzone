<?php
session_start();

$host_name = 'localhost';
$user_name = 'root';
$db_name = 'shopping2';
$db = mysqli_connect($host_name, $user_name, '', $db_name);
if (!$db) {
    mysqli_connect_error($db);
    echo "داتا بەیس کۆنێکت نییە";
}
function bootstrap()
{
    echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"  rel="stylesheet">';
}
function function_alert($message)
{
    // Display the alert box 
    echo "<script>alert('$message');</script>";
}
function clear($data)
{
    global $db;
    $data = htmlspecialchars($data);
    $data = mysqli_real_escape_string($db, $data);
    $data = trim($data);
    $data = stripslashes($data);
    return $data;
}

if (isset($_GET['logout'])) {
    $id = $_GET['logout'];

    session_unset();
    session_destroy();
    unset($_SESSION['superadmin']);
    unset($_SESSION['admin']);
    unset($id);
    header('location:login.php');
}
