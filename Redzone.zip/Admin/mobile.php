<?php include './inc/nav.php';  ?>

<div class="heading">
    <div class="head">
        <p>مۆبایل</p>
        <a href="./add/item.php"><i class='bx bx-plus fs-3 text-white me-2'></i>زیادکردنی بابەت</a>
    </div>
</div>

<div class="row justify-content-center p-1 ">
    <?php require('./inc/update.php'); ?>
    <?php
    $query = mysqli_query($db, "SELECT * FROM `item` WHERE `type_item` = 'mobile' ORDER BY `id` DESC");
    if ($query) {
        while ($row = mysqli_fetch_assoc($query)) {
            $id = $row['id'];
            $name = $row['name'];
            $details = $row['details'];
            $price = $row['price'];
            $photo = $row['photo'];
    ?>
            <?php require('./modal/mobile.php'); ?>
            <div class="card card_computer m-2 p-2" style="width: 17rem; height:23rem;position:relative;">
                <img src="./upload/<?php echo $photo; ?>" class="card-img-top" style="width:90%; height:auto;object-fit:cover; margin-left:50%;transform:translateX(-50%)">
                <div class="card-body pt-4">
                    <h5 class="card-title fs-4"><?php echo $name; ?></h5>
                    <p class="card-text fs-6"><?php echo $price; ?>$</p>
                    <div class="bottom">
                        <a data-bs-toggle="modal" data-bs-target="#update<?php echo $id; ?>"><i class="fal fa-pen "></i></a>
                        <?php if (isset($_SESSION['superadmin'])) { ?>
                            <a href="./inc/delete.php?mobile=<?php echo $id; ?>"><i class="fal fa-trash "></i></a>
                        <?php } ?>
                        <a data-bs-toggle="modal" data-bs-target="#view-post<?php echo $id; ?>"><i class="fal fa-clipboard "></i></a>
                    </div>
                </div>
            </div>
    <?php
        }
    } else {
        echo '<p class="text-danger text-center fs-3">! هیچ داتایەک نیە </p>';
    }
    ?>

</div>



<?php include './inc/footer.php';  ?>