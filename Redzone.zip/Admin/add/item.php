<?php include('../inc/config.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <?php bootstrap(); ?>
</head>
<?php 
$error['err'] = '';
if (isset($_POST['upload'])) {
    $name = clear($_POST['name']);
    $desc = clear($_POST['details']);
    $price = clear($_POST['price']);
    $type_item = clear($_POST['type_item']);
    $file = $_FILES['image'];
    $fileName = $_FILES['image']['name'];
    $fileType = $_FILES['image']['type'];
    $fileTmpName = $_FILES['image']['tmp_name'];
    $fileError = $_FILES['image']['error'];
    $fileSize = $_FILES['image']['size'];
    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));
    $fileAllowedextensions = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'svg');

    if (empty($name) && empty($desc) && empty($price) && empty($type_item)) {
        $error['err'] = 'خانەکان پربکەرەوە';
    } elseif (empty($name)) {
        $error['err'] = 'ناوی بابەت بنووسە';
    } elseif (empty($price)) {
        $error['err'] = 'نرخی بابەت بنووسە';
    } elseif (!is_numeric($price)) {
        $error['err'] = 'خانەی نرخ تەنها قبوڵی ژمارە دەکات';
    } else if ($type_item == 'null') {
        $error['err'] = 'جۆری بابەت دیاریبکە';
    }elseif(empty($file)){
        $error['err'] = ' وێنەیەک دیاریبکە';
    } 
    else {
        if (in_array($fileActualExt, $fileAllowedextensions)) { //agar true bw
            if ($fileError === 0) {
                if ($fileSize < 10000000) { //file size hata 10 mb qbwle dakat dana dabeta else
                    $fileNewname = rand() . rand() . "." . $fileActualExt; // lera naweke taza bo imgaka dadanen 1 rand nawakayate 2 .dot 
                    $filefrom = "../upload/$fileNewname"; // amayan bo awa bakar det bman bat bo kwe yan rmaka lawe upload bkat
                    move_uploaded_file($fileTmpName, $filefrom); //amash bo move krdny img
                    if ($type_item != 'null') {
                        if (empty($desc)) {
                            $error['err'] = 'دەربارەی بابەت بنووسە';
                        }
                    }
                    $sql = "INSERT INTO `item` SET
                        `name`='$name',
                        `details`='$desc',
                        `price`='$price',
                        `photo`='$fileNewname',
                        `type_item`='$type_item'
                        ";
                    $query = mysqli_query($db, $sql);
                    if ($query) {
                        $_SESSION['status'] = '! بابەت زیاد کرا';
                        $_SESSION['status-code'] = 'success';
                        if ($type_item == 'computer') {
                            header('Location:../computer.php');
                        } elseif ($type_item == 'mobile') {
                            header('Location:../mobile.php');
                        }
                    } else {
                        echo 'fail';
                    }
                } else {
                    $error['err'] ='قەبارەی وێنەکە گەورەیە وێنەیەکی تر تاقیبکەوە ';
                }
            } else {
                $error['err'] ='وێنەیەکی تر هەڵبژێرە';
            }
        } else {
            $error['err'] ='وێنەیەک دیاریبکە';
        }
        // echo 'done';
    }
}
?>
<body>
    <div class="container add-item">
        <div class="back">
            <a href="../computer.php"><i class='bx bx-left-arrow-alt'></i></a>
        </div>
        <div class="msg">
            <?php if (isset($_POST['upload'])) { ?>
                <p class="text-danger text-center fs-5 p-1 mt-4"><?php echo $error['err']; ?></p>
            <?php } ?>
        </div>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <input type="text" class="form-control" name="name" placeholder="ناوی بابەت" <?php if (isset($_POST['upload'])) { ?> value="<?php echo $name ?>" <?php } ?>>
            </div>
            <div class=" mb-3">
                <input type="text" name="price" class="form-control" placeholder="نرخی بابەت" <?php if (isset($_POST['upload'])) { ?> value="<?php echo $price ?>" <?php } ?>>
            </div>
            <div class="mb-3">
                <textarea class="form-control" name="details" id="" cols="30" rows="5" placeholder="دەربارەی بابەت"></textarea>
            </div>
            <div class="mb-3">
                <input type="file" name="image" class="form-control">
            </div>
            <div class="mb-3">
                <select name="type_item" id="" class="form-control">
                    <option value="null">جۆری بابەت دیاری بکە</option>
                    <option value="computer">Computer</option>
                    <option value="mobile">Mobile</option>
                </select>
            </div>

            <div class="mt-3">
                <button type="submit" name="upload">زیادکردن</button>
            </div>

        </form>
    </div>
</body>