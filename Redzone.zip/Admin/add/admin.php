<?php include('../inc/config.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <?php bootstrap(); ?>
</head>
<?php
$error = ['err' => ''];
if (isset($_POST['add-admin']) && isset($_SESSION['superadmin'])) {
    $name = clear($_POST['name']);
    $username = clear($_POST['username']);
    $email = clear($_POST['email']);
    $phone_num = clear($_POST['phone_number']);
    $admins = clear($_POST['admins']);
    $pwd = clear($_POST['pwd']);
    $pwd_rep = clear($_POST['pwd_rep']);
    $hash_pwd = password_hash($pwd, PASSWORD_DEFAULT);
    $admin_id = rand().rand().rand();
    if (empty($name) && empty($username) && empty($email) && empty($pwd) && empty($pwd_rep) && empty($phone_num)) {
        $error['err'] = 'خانەکان پربکەرەوە';
    } else if (empty($name)) {
        $error['err'] = 'خانەی ناو بەتاڵە';
    } else if (empty($username)) {
        $error['err'] = 'خانەی نازناو بەتاڵە';
    } else if (empty($phone_num)) {
        $error['err'] = 'ژمارەی مۆبایل داخڵ بکە';
    } else if (empty($email)) {
        $error['err'] = 'خانەی ئیمێڵ بەتاڵە';
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error['err'] = ' ئیمێڵ گونجاو نیە';
    } else if (empty($pwd)) {
        $error['err'] = 'وشەی نهێنی بنووسە';
    } elseif (strlen($pwd) < 8 && strlen($pwd_rep) < 8) {
        $error['err'] = '  وشەی نهێنی لاوازە';
    } else if ($pwd != $pwd_rep) {
        $error['err'] = 'دڵنیابەرەوە لە وشەی نهێنی';
    } else if (!is_numeric($phone_num)) {
        $error['err'] = 'ژمارەی مۆبایل گونجاو نیە';
    } else {
        // echo 'done';
        $sql_user = "SELECT * FROM `admin` WHERE `username` = '$username' ";
        $q_user = mysqli_query($db, $sql_user);
        $sql_email = "SELECT * FROM `admin` WHERE `email` = '$email' ";
        $q_email = mysqli_query($db, $sql_user);
        $found_user = mysqli_num_rows($q_user);

        if ($found_user > 0) {
            $error['err'] = 'نازناو دوبارەیە';
        } elseif (mysqli_num_rows($q_email) > 0) {
            $error['err'] = 'ئیمێڵ دوبارەیە';
        } else {
            $sql = "INSERT INTO `admin` SET 
            `name` = '$name',
            `username` = '$username',
            `num_phone` = '$phone_num',
            `email` = '$email',
            `password` = '$hash_pwd',
            `role` = '$admins',
            `admin_id` = '$admin_id'
             ";
            $query = mysqli_query($db, $sql);
            if ($query) {
                // echo 'done';
                $_SESSION['status'] = '! بەرێوبەر زیاد کرا ';
                $_SESSION['status-code'] = 'success';
                $_SESSION['admin_id'] =$admin_id;
                header('Location:../admin.php');
            } else {
                //echo  'file';
                $_SESSION['status'] = '! بەرێوبەر زیاد نەکرا';
                $_SESSION['status-code'] = 'error';
                header('Location:../admin.php');
            }
        }
        exit();
    }
} ?>

<body>
    <div class="container add">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <div class="back">
                <a href="../admin.php"><i class='bx bx-left-arrow-alt'></i></a>
            </div>
            <div class="msg">
                <?php if (isset($_POST['add-admin'])) { ?>
                    <p class="text-danger text-center fs-5 p-1 mt-4"><?php echo $error['err']; ?></p>
                <?php } ?>
            </div>
            <div class="inputs">
                <input type="text" placeholder="ناو" <?php if (isset($_POST['add-admin'])) {  ?> value="<?php echo $name ?>" <?php } ?> name="name">
                <input type="text" placeholder="نازناو" <?php if (isset($_POST['add-admin'])) {  ?> value="<?php echo $username ?>" <?php } ?> name="username">
                <input type="text" placeholder="ژمارەی مۆبایل" <?php if (isset($_POST['add-admin'])) { ?> value="<?php echo $phone_num ?>" <?php } ?> name="phone_number">
                <input type="email" placeholder="ئیمێڵ" <?php if (isset($_POST['add-admin'])) { ?> value="<?php echo $email ?>" <?php } ?> name="email">
                <input type="password" placeholder="وشەی نهێنی" name="pwd">
                <input type="password" placeholder=" دوبارە کردنەوەی وشەی نهێنی" name="pwd_rep">
                <?php if (isset($_SESSION['superadmin'])) { ?>
                    <select name="admins" id="">
                        <option value="SuperAdmin">Super Admin</option>
                        <option value="Admin">Admin</option>
                    </select>
                <?php } ?>
                <button type="submit" class="text-white" name="add-admin">زیادکردن</button>
            </div>
        </form>
    </div>
</body>

</html>