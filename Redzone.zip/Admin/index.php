<?php include './inc/nav.php';

?>

<div class="row mt-5 ">
    <p class="text-center fs-3 text-dark">
        <?php
        if (isset($_SESSION['superadmin'])) {
            echo $_SESSION['superadmin'];
            echo '</br>';
            echo $_SESSION['role-super'];
        } else {
            echo $_SESSION['admin'];
            echo '</br>';
            echo $_SESSION['role-admin'];
        }
        // if(isset($_SESSION['admin_id'])){
        //     echo $_SESSION['admin_id'];
        // }
        ?>
    </p>
</div>
<?php
$query_admin = mysqli_query($db, 'SELECT * FROM `admin`');
if ($query_admin) {
    $row_admin = mysqli_num_rows($query_admin);
}
$query_item = mysqli_query($db, 'SELECT * FROM `item`');
if ($query_item) {
    $row_item = mysqli_num_rows($query_item);
}
$query_order = mysqli_query($db, 'SELECT * FROM `order_user`');
if ($query_order) {
    $row_order = mysqli_num_rows($query_order);
}
?>
<div class="container p-1">
    <div class="row justify-content-center mt-4">
        <?php
        $i = 0;
        while ($i < 3) { ?>
            <div class="card m-4 shadow-sm" style="width: 20rem ; height:20rem;" dir="rtl">
                <img src="./assets/img/<?php if ($i == 0) {
                                            echo 'admin.png';
                                        } elseif ($i == 1) {
                                            echo 'product.png';
                                        } else {
                                            echo 'order.png';
                                        } ?>" class="card-img-top p-2 mt-2" style="width:50%; margin-left:50%;transform:translateX(-50%);">
                <div class="card-body">
                    <h5 class="card-title text-center fs-4 text-info"><?php if ($i == 0) {
                                                                            echo 'بەرێوبەر';
                                                                        } elseif ($i == 1) {
                                                                            echo 'بەرهەمەکان';
                                                                        } else {
                                                                            echo 'داواکاریەکان';
                                                                        } ?></h5>
                    <p class="card-text text-right text-dark mt-3"><?php if ($i == 0) {
                                                                        echo 'ژمارەی بەرێوبەر : ' . $row_admin;
                                                                    } elseif ($i == 1) {
                                                                        echo 'ژمارەی بەرهەمەکان : ' . $row_item;
                                                                    } else {
                                                                        echo 'ژمارەی داواکاریەکان : ' . $row_order;
                                                                    } ?></p>
                    <div class="row">
                        <?php
                        if ($i == 0) {
                            echo '<a href="admin.php" class="btn btn-primary text-white w-50 m-auto">بەرێوبەر</a>';
                        } elseif ($i == 1) {
                            echo '<a href="computer.php" class="btn btn-primary text-white w-50 m-auto">بەرهەمەکان</a>';
                        } else {
                            echo '<a href="order.php" class="btn btn-primary text-white w-50 m-auto">داواکاریەکان</a>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php
            $i++;
        }
        ?>
    </div>
</div>

<?php include './inc/footer.php';  ?>