<?php include './inc/nav.php';  ?>
<div class="heading">
    <div class="head">
        <p>کۆمپیوتەر</p>
        <a href="./add/item.php"><i class='bx bx-plus fs-3 text-white me-2'></i>زیادکردنی بابەت</a>
    </div>
</div>
<?php require('./inc/update.php'); ?>
<div class="row p-1 justify-content-center pb-3">
    <?php
    $sql = "SELECT * FROM `item` WHERE `type_item`='computer' ORDER BY `id` DESC ";
    $query = mysqli_query($db, $sql);
    if ($query) {
        while ($row = mysqli_fetch_assoc($query)) {
            $id  = $row['id'];
            $name = $row['name'];
            $details = $row['details'];
            $price = $row['price'];
            $photo = $row['photo'];
    ?>
            <?php require('./modal/computer.php') ?>
            <div class="card card_computer m-2  p-0" style="width: 18rem; height:19rem;position:relative;">
                <img src="./upload/<?php echo $photo; ?>" class="card-img-top" style="width:80%; height:auto;object-fit:cover; margin-left:50%;transform:translateX(-50%)">
                <div class="card-body pt-4">
                    <h5 class="card-title fs-4"><?php echo $name; ?></h5>
                    <p class="card-text fs-6"><?php echo $price; ?>$</p>
                </div>
                <div class="bottom ">
                    <a data-bs-toggle="modal" data-bs-target="#update<?php echo $id; ?>"><i class="fal fa-pen "></i></a>
                    <?php if (isset($_SESSION['superadmin'])) { ?>
                        <a href="./inc/delete.php?computer=<?php echo $id; ?>"><i class="fal fa-trash "></i></a>
                    <?php } ?>
                    <a data-bs-toggle="modal" data-bs-target="#view-post<?php echo $id; ?>"><i class="fal fa-clipboard "></i></a>
                </div>
            </div>
    <?php }
    } else {
        echo 'هحچ داتایەک نیە';
    }    ?>
</div>
<?php include './inc/footer.php';  ?>