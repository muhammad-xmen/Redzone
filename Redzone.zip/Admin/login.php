<?php include('inc/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<?php
$error = ['err' => ''];

if (isset($_POST['login'])) {
    //echo 'login';

    $email = clear($_POST['email']);
    $password = clear($_POST['password']);
    $admins = clear($_POST['admins']);
    if (empty($email) && empty($password)) {
        $error['err'] = 'خانەکان پربکەرەوە';
    } else if (empty($email)) {
        $error['err'] = ' خانەی ئیمێڵ بەتاڵە';
    } else if (empty($password)) {
        $error['err'] = ' خانەی وشەی نهێنی بەتاڵە';
    } else {
        $sql = "SELECT * FROM `admin` WHERE `email` = '$email' && `role` = '$admins'";
        $query = mysqli_query($db, $sql);
        $numRows = mysqli_num_rows($query);
        if ($numRows > 0) {
            // echo 'haya';
            $row = mysqli_fetch_array($query);
            if (password_verify($password, $row['password'])) {
                if ($admins == 'SuperAdmin') {
                    $_SESSION['superadmin'] = $row['name'];
                    $_SESSION['role-super'] = $row['role'];
                    $_SESSION['superadmin_id'] = $row['admin_id'];
                    $_SESSION['status'] = $row['name'] .'بەخێربێت';
                    $_SESSION['status-code'] = 'success';
                } elseif ($admins == 'Admin') {
                    $_SESSION['admin'] = $row['name'];
                    $_SESSION['role-admin'] = $row['role'];
                    $_SESSION['admin_id'] = $row['admin_id'];
                    $_SESSION['status'] = $row['name']  . 'بەخێربێت';
                    $_SESSION['status-code'] = 'success';
                }

                header('Location:index.php');
            } else {
                $error['err'] = 'دڵنیابەرەوە لە وشەی نهێنی';
            }
        } else {
            $error['err'] = 'هیچ کەسێک نەدۆزرایەوە';
        }
    }
}

?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./assets/css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <?php bootstrap(); ?>
</head>

<body>
    <div class="login">
        <div class="content">
            <div class="msg">
                <?php if (isset($_POST['login'])) { ?>
                    <p class="text-danger text-center pt-3 fs-4"><?php echo  $error['err']; ?></p>
                <?php } ?>
            </div>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <div class="box">
                    <label for="text">email</label>
                    <input type="text" name="email" <?php if (isset($_POST['login'])) { ?> value="<?php echo $email; ?>" <?php } ?>>
                </div>
                <div class="box">
                    <label for="text">passowrd</label>
                    <input type="password" name="password">
                </div>
                <div class="box">
                    <select name="admins">
                        <option value="SuperAdmin">Super Admin</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>
                <button type="submit" name="login">Login</button>
            </form>
        </div>
    </div>
</body>

</html>