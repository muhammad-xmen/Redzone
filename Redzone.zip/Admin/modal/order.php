<!-- Modal -->
<div class="modal fade" id="order<?php echo  $id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-3 text-capitalize" id="order"><?php echo $name; ?></h5>
            </div>
            <div class="modal-body">
                <div class="container">
                    <img src="./upload/<?php echo $photo; ?>" class="w-50 rounded-3 mb-4" style="margin-left:50%;transform:translateX(-50%);">
                    <div class="row">
                        <p class="text-center fs-5"><?php echo $number_phone; ?></p>
                        <p class="text-center fs-5"><?php echo $email_user; ?></p>
                        <p class="text-center fs-5"><?php echo $city_user; ?> : شوێن </p>
                        <div class="row" dir="rtl">
                            <p class="text-right"> ژمارەی داواکاری : <?php echo $qut; ?> </p>
                            <p> نرخی کۆی بەرهەم : <?php echo $total_item_price . '$'; ?> </p>
                            <p> کاتی داواکاری : <?php echo $date; ?> </p>
                        </div>
                    </div>
                </div>
            </div>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <div class="modal-footer d-flex justify-content-center">
                    <input type="hidden" name="id" value="<?php echo $id ?>">
                    <?php if ($status == 'not-order') { ?>
                        <button type="submit" class="btn btn-primary w-25 m-2 p-2 text-white" name="accept">accept</button>
                    <?php } else { ?>
                        <button type="submit" class="btn btn-danger w-25 m-2 p-2  text-white" name="delete">delete</button>
                    <?php } ?>
                </div>
            </form>
        </div>
    </div>
</div>