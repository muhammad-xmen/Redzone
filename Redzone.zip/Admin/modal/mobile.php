<div class="modal fade" id="view-post<?php echo $id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-4" id="exampleModalLabel"><?php echo $name; ?></h5>
            </div>
            <div class="modal-body">
            <div class="row" ">
                                <img src=" ./upload/<?php echo $photo; ?>" style="width: 70%; height:auto:object-fit:cover; margin:0 auto;">
                </div>
                <div class="row">
                    <p><?php echo $details; ?></p>
                    <p><?php echo $price; ?>$</p>
                </div>
                <button type="button" class="btn btn-danger w-100 p-1 fs-5 text-white" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="update<?php echo $id; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-4 p-2" id="staticBackdropLabel">Modal title</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                        <div class="mb-3">
                            <input type="text" name="name" class="form-control fs-5 p-2 " value="<?php echo $name; ?>">
                            <input type="hidden" name="id" class="form-control" value="<?php echo $id; ?>">
                        </div>
                        <div class="mb-3">
                            <textarea name="details" id="" cols="30" rows="4" class="form-control fs-5 p-2 "><?php echo $details; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <input type="text" name="price" class="form-control  fs-5 p-2" value="<?php echo $price; ?>">
                        </div>
                        <button type="submit" name="update-mobile" class="btn btn-success text-white  w-100 fs-5 p-1">دەستکاری کردن</button>
                        <button type="button" class="btn btn-danger text-white w-100 fs-5 p-1 mt-2" data-bs-dismiss="modal">Close</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>