<!-- view -->
<div class="modal fade" id="view<?php echo $id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-4 pt-2" id="exampleModalLabel"><?php echo $name; ?></h5>
            </div>
            <div class="modal-body">
                <div class="row text-center">
                    <p class="fs-3 mb-2 ">  <?php echo $username; ?></p>
                    <p class="fs-4 mb-2 "><?php echo $phone; ?><i class="fal fa-phone m-2 fs-4"></i></p>
                    <p class="fs-5 mb-2 "><?php echo $email; ?> <i class="fal fa-envelope  m-2 fs-4"></i></p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger w-100 p-2 text-white" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- update -->
<div class="modal fade" id="update<?php echo $id; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-3" id="staticBackdropLabel" style="text-transform: capitalize;"><?php echo $name; ?> </h5>
            </div>
            <div class="modal-body p-3">
                <form action="<?php echo $_SERVER['PHP_SELF'] ?> " method="POST">
                <input type="text" name="id" value="<?php echo $id; ?>" hidden >
                    <div class="mb-3">
                        <input type="text" class="form-control fs-4" name="name" value="<?php echo $name; ?>">
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control fs-4" name="username" value="<?php echo $username; ?>">
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control fs-4" name="phone" value="<?php echo $phone; ?>">
                    </div>
                    <button type="submit" name="update-admin" class="btn btn-success w-100 p-1 text-white fs-5">Submit</button>
                    <button type="button" class="btn btn-danger w-100 p-1 text-white mt-3 fs-5" data-bs-dismiss="modal">Close</button>
                </form>
            </div>

        </div>
    </div>
</div>