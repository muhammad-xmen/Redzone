<?php require('./inc/nav.php'); ?>
<?php
if (isset($_POST['accept'])) {
    $id = clear($_POST['id']);
    $sql_update = "UPDATE `order_user`SET `request`='ordered'  WHERE `id`='$id' ";
    $query_update = mysqli_query($db, $sql_update);
    if ($query_update) {
        $_SESSION['status'] = 'داواکاریەکە قبول کرا';
        $_SESSION['status-code'] = 'success';
        header('Location:order.php');
    }
}
?> 
<?php
if (isset($_POST['delete'])) {
    $id = clear($_POST['id']);
    $query_delete = mysqli_query($db, "DELETE  FROM `order_user` WHERE `id` = '$id'");
    if ($query_delete) {
        $_SESSION['status'] = 'داواکاری رەشکرایەوە';
        $_SESSION['status-code'] = 'success';
        header('Location:order.php');
    }
}

?>
<div class="order">
    <div class=" p-2 mt-5">
        <div class="row justify-content-center p-1 gap-3">
            <?php
            $sql = "SELECT * FROM `order_user` ORDER BY `id` DESC ";
            $query = mysqli_query($db, $sql);
            if ($query) {
                while ($row = mysqli_fetch_assoc($query)) {
                    $id = $row['id'];
                    $name = $row['name_user'];
                    $number_phone = $row['phone_user'];
                    $email_user = $row['email_user'];
                    $city_user = $row['city_user'];
                    $date = $row['date'];
                    $color_item = $row['color_item'];
                    $photo = $row['photo'];
                    $qut = $row['quantity'];
                    $total_item_price = $row['total_item_price'];
                    $status = $row['request'];
                    include('./modal/order.php');
            ?>
                    <div class="card m-2 " style="width:16rem;height:18rem; ">
                        <div class="card-body">
                            <h5 class="card-title text-capitalize"><?php echo $name; ?></h5>
                            <div class="row">
                                <p><?php echo $number_phone; ?></p>
                                <p><?php echo $email_user; ?> </p>
                            </div>
                            <div class="row d-flex justify-content-center" style="position: absolute !important;bottom: 0px !important;">
                                <a href="" data-bs-toggle="modal" data-bs-target="#order<?php echo $id; ?>" class="btn_order mb-3 p-2 btn btn-warning ">View Order</a>
                                <p href="" class="btn_order2 text-capitalize text-white btn mb-1 <?php if ($status == 'not-order') {
                                                                                                        echo "btn-danger";
                                                                                                    } else {
                                                                                                        echo "btn-success";
                                                                                                    } ?> fs-5 " disabled> <?php echo $status; ?></p>
                            </div>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<p class="text-center text-danger fs-3 p-3">! هیچ داواکاریەک نیە </p>';
            }
            ?>
        </div>
    </div>
</div>
<?php require('./inc/footer.php'); ?>